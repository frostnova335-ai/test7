/** Local compatibility shims to satisfy TS in Superset v5 moves */
export type QueryFormData = any;
export type QueryFormMetric = any;
export type QueryFormColumn = any;
export type Metric = any;
export type AnnotationResult = any;
export enum GenericDataType {
  NUMERIC = "NUMERIC",
  STRING = "STRING",
  TEMPORAL = "TEMPORAL",
  BOOLEAN = "BOOLEAN",
  UNKNOWN = "UNKNOWN"
}
export const SMART_DATE_ID = "smart_date";
