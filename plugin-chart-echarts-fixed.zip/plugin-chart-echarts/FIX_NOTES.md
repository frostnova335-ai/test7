Patched for Superset v5 TypeScript compatibility:

- Added tsconfig settings: jsx=react-jsx, jsxImportSource=@emotion/react, esModuleInterop=true, downlevelIteration=true
- Updated imports of GenericDataType to come from '@superset-ui/chart-controls' (was '@superset-ui/core')
- Mapped deprecated theme.colors.* usages to Ant Design v5 tokens (colorText, colorTextSecondary, colorSuccessBg, colorErrorBg)
- Fixed numeric operations in BigNumber PoP transformProps to coerce values to numbers before arithmetic

You may still need to ensure your root webpack/ts-loader picks up this package tsconfig.
