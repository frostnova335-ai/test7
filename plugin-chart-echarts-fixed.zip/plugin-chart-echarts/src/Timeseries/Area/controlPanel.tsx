import { t } from '@superset-ui/core';
import {
  ControlPanelConfig,
  ControlPanelsContainerProps,
  ControlSubSectionHeader,
  D3_TIME_FORMAT_DOCS,
  getStandardizedControls,
  sections,
  sharedControls,
} from '@superset-ui/chart-controls';

import { EchartsTimeseriesSeriesType } from '../types';
import { DEFAULT_FORM_DATA, TIME_SERIES_DESCRIPTION_TEXT } from '../constants';
import {
  legendSection,
  onlyTotalControl,
  showValueControl,
  richTooltipSection,
  seriesOrderSection,
  percentageThresholdControl,
  xAxisLabelRotation,
  xAxisLabelInterval,
  truncateXAxis,
  xAxisBounds,
  minorTicks,
} from '../../controls';
import { AreaChartStackControlOptions } from '../../constants';

const {
  logAxis,
  markerEnabled,
  markerSize,
  minorSplitLine,
  opacity,
  rowLimit,
  seriesType,
  truncateYAxis,
  yAxisBounds,
  zoomable,
} = DEFAULT_FORM_DATA;

const config: ControlPanelConfig = {
  controlPanelSections: [
    {
      ...sections.echartsTimeSeriesQueryWithXAxisSort,
      controlSetRows: [
        ...sections.echartsTimeSeriesQueryWithXAxisSort.controlSetRows,
        [
          {
            name: 'extra_tooltip_field',
            config: {
              type: 'SelectControl',
              label: t('Extra Tooltip Field'),
              default: null,
              renderTrigger: true,
              clearable: true,
              description: t('Pick a column to show its value in the tooltip.'),
              mapStateToProps: (state: any) => {
                const columns = state.datasource?.columns || [];
                return {
                  choices: columns
                    .filter((col: any) => typeof col?.column_name === 'string')
                    .map((col: any) => {
                      const label =
                        'verbose_name' in col && col.verbose_name
                          ? col.verbose_name
                          : col.column_name;
                      return [col.column_name, label];
                    }),
                };
              },
            },
          },
        ],
      ],
    },
    sections.advancedAnalyticsControls,
    sections.annotationsAndLayersControls,
    sections.forecastIntervalControls,
    sections.titleControls,
    {
      label: t('Chart Options'),
      expanded: true,
      controlSetRows: [
        ...seriesOrderSection,
        ['color_scheme'],
        ['time_shift_color'],
        [
          {
            name: 'seriesType',
            config: {
              type: 'SelectControl',
              label: t('Series Style'),
              renderTrigger: true,
              default: seriesType,
              choices: [
                [EchartsTimeseriesSeriesType.Line, t('Line')],
                [EchartsTimeseriesSeriesType.Smooth, t('Smooth Line')],
                [EchartsTimeseriesSeriesType.Start, t('Step - start')],
                [EchartsTimeseriesSeriesType.Middle, t('Step - middle')],
                [EchartsTimeseriesSeriesType.End, t('Step - end')],
              ],
              description: t('Series chart type (line, bar etc)'),
            },
          },
        ],
        [
          {
            name: 'opacity',
            config: {
              type: 'SliderControl',
              label: t('Area chart opacity'),
              renderTrigger: true,
              min: 0,
              max: 1,
              step: 0.1,
              default: opacity,
              description: t(
                'Opacity of Area Chart. Also applies to confidence band.',
              ),
            },
          },
        ],
        [showValueControl],
        [
          {
            name: 'stack',
            config: {
              type: 'SelectControl',
              label: t('Stacked Style'),
              renderTrigger: true,
              choices: AreaChartStackControlOptions,
              default: null,
              description: t('Stack series on top of each other'),
            },
          },
        ],
        [onlyTotalControl],
        [percentageThresholdControl],
        [
          {
            name: 'show_extra_controls',
            config: {
              type: 'CheckboxControl',
              label: t('Extra Controls'),
              renderTrigger: true,
              default: false,
              description: t(
                'Whether to show extra controls or not. Extra controls ' +
                  'include things like making multiBar charts stacked ' +
                  'or side by side.',
              ),
            },
          },
        ],
        [
          {
            name: 'markerEnabled',
            config: {
              type: 'CheckboxControl',
              label: t('Marker'),
              renderTrigger: true,
              default: markerEnabled,
              description: t(
                'Draw a marker on data points. Only applicable for line types.',
              ),
            },
          },
        ],
        [
          {
            name: 'markerSize',
            config: {
              type: 'SliderControl',
              label: t('Marker Size'),
              renderTrigger: true,
              min: 0,
              max: 20,
              default: markerSize,
              description: t(
                'Size of marker. Also applies to forecast observations.',
              ),
              visibility: ({ controls }: ControlPanelsContainerProps) =>
                Boolean(controls?.markerEnabled?.value),
            },
          },
        ],
        [minorTicks],
        [
          {
            name: 'zoomable',
            config: {
              type: 'CheckboxControl',
              label: t('Data Zoom'),
              default: zoomable,
              renderTrigger: true,
              description: t('Enable data zooming controls'),
            },
          },
        ],
        ...legendSection,
        [<ControlSubSectionHeader>{t('X Axis')}</ControlSubSectionHeader>],
        [
          {
            name: 'x_axis_time_format',
            config: {
              ...sharedControls.x_axis_time_format,
              default: 'smart_date',
              description: `${D3_TIME_FORMAT_DOCS}. ${TIME_SERIES_DESCRIPTION_TEXT}`,
            },
          },
        ],
        [xAxisLabelRotation],
        [xAxisLabelInterval],
        ...richTooltipSection,
        [<ControlSubSectionHeader>{t('Y Axis')}</ControlSubSectionHeader>],
        ['y_axis_format'],
        ['currency_format'],
        [
          {
            name: 'logAxis',
            config: {
              type: 'CheckboxControl',
              label: t('Logarithmic y-axis'),
              renderTrigger: true,
              default: logAxis,
              description: t('Logarithmic y-axis'),
            },
          },
        ],
        [
          {
            name: 'minorSplitLine',
            config: {
              type: 'CheckboxControl',
              label: t('Minor Split Line'),
              renderTrigger: true,
              default: minorSplitLine,
              description: t('Draw split lines for minor y-axis ticks'),
            },
          },
        ],
        [truncateXAxis],
        [xAxisBounds],
        [
          {
            name: 'truncateYAxis',
            config: {
              type: 'CheckboxControl',
              label: t('Truncate Y Axis'),
              default: truncateYAxis,
              renderTrigger: true,
              description: t(
                'Truncate Y Axis. Can be overridden by specifying a min or max bound.',
              ),
            },
          },
        ],
        [
          {
            name: 'y_axis_bounds',
            config: {
              type: 'BoundsControl',
              label: t('Y Axis Bounds'),
              renderTrigger: true,
              default: yAxisBounds,
              description: t(
                'Bounds for the Y-axis. When left empty, the bounds are ' +
                  'dynamically defined based on the min/max of the data. Note that ' +
                  "this feature will only expand the axis range. It won't " +
                  "narrow the data's extent.",
              ),
              visibility: ({ controls }: ControlPanelsContainerProps) =>
                Boolean(controls?.truncateYAxis?.value),
            },
          },
        ],
      ],
    },
  ],
  controlOverrides: {
    row_limit: {
      default: rowLimit,
    },
  },
  formDataOverrides: formData => ({
    ...formData,
    metrics: getStandardizedControls().popAllMetrics(),
    groupby: getStandardizedControls().popAllColumns(),
  }),
};

export default config;
